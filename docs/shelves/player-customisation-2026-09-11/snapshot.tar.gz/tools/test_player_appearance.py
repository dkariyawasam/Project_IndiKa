#!/usr/bin/env python3
"""Exercise the actual palette code with host-side GBA palette/save stubs."""
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='appearance-test-') as temp:
    work = Path(temp)
    (work / 'global.h').write_text('''#include <stdint.h>
#include <string.h>
typedef uint8_t u8; typedef uint16_t u16; typedef uint8_t bool8;
#define RGB(r,g,b) ((r) | ((g)<<5) | ((b)<<10))
struct SaveBlock2 { u8 appearanceVersion, hairColor, accentColor; };
extern struct SaveBlock2 *gSaveBlock2Ptr;
extern u16 gPlttBufferUnfaded[512];
#define CpuCopy16(src,dst,size) memcpy(dst,src,size)
void LoadPalette(const void *src, u16 offset, u16 size);
''')
    (work / 'gflib.h').write_text('')
    (work / 'test.c').write_text('''#include "global.h"
#include "player_appearance.h"
#include <assert.h>
#include <stdio.h>
struct SaveBlock2 save, *gSaveBlock2Ptr = &save;
u16 gPlttBufferUnfaded[512];
void LoadPalette(const void *src, u16 offset, u16 size) {
    assert(offset + size / 2 <= 512);
    memcpy(gPlttBufferUnfaded + offset, src, size);
}
int main(void) {
    u16 original[512];
    int i, kind, hair, accent;
    struct SaveBlock2 stored;
    for (i = 0; i < 512; i++) original[i] = (i * 53) & 0x7FFF;
    for (kind = 0; kind <= PLAYER_PALETTE_CREDITS; kind++) {
        memcpy(gPlttBufferUnfaded, original, sizeof(original));
        memset(&save, 0, sizeof(save));
        ApplyPlayerAppearancePalette(64, kind);
        assert(!memcmp(original, gPlttBufferUnfaded, sizeof(original)));
        ResetPlayerAppearance();
        ApplyPlayerAppearancePalette(64, kind);
        assert(!memcmp(original, gPlttBufferUnfaded, sizeof(original)));
        for (hair = 0; hair < PLAYER_HAIR_COLOR_COUNT; hair++) {
            for (accent = 0; accent < PLAYER_ACCENT_COLOR_COUNT; accent++) {
                int count = kind == PLAYER_PALETTE_INTRO ? 32 : 16;
                memcpy(gPlttBufferUnfaded, original, sizeof(original));
                save.hairColor = hair; save.accentColor = accent;
                memcpy(&stored, &save, sizeof(save));
                memset(&save, 0, sizeof(save));
                memcpy(&save, &stored, sizeof(save));
                assert(HasPlayerAppearance());
                ApplyPlayerAppearancePalette(64, kind);
                assert(!memcmp(original, gPlttBufferUnfaded, 64 * 2));
                assert(!memcmp(original + 64 + count, gPlttBufferUnfaded + 64 + count,
                               (512 - 64 - count) * 2));
                assert(gPlttBufferUnfaded[64] == original[64]);
                // Skin highlights remain independent of both chosen colours.
                assert(gPlttBufferUnfaded[66] == original[66]);
                assert(gPlttBufferUnfaded[67] == original[67]);
                for (i = 64; i < 64 + count; i++) assert(gPlttBufferUnfaded[i] <= 0x7FFF);
            }
        }
        memcpy(gPlttBufferUnfaded, original, sizeof(original));
        save.hairColor = 255;
        assert(!HasPlayerAppearance());
        ApplyPlayerAppearancePalette(64, kind);
        assert(!memcmp(original, gPlttBufferUnfaded, sizeof(original)));
    }
    puts("Passed: 245 palette combinations, legacy defaults, invalid values, bounds and save round trips.");
}
''')
    binary = work / 'test'
    subprocess.run(['cc', '-std=c99', '-Wall', '-Wextra', '-Werror',
                    '-I'+str(work), '-I'+str(ROOT / 'include'),
                    str(ROOT / 'src/player_appearance.c'), str(work / 'test.c'),
                    '-o', str(binary)], check=True)
    subprocess.run([str(binary)], check=True)
