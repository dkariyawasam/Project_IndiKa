#ifndef GUARD_PLAYER_APPEARANCE_H
#define GUARD_PLAYER_APPEARANCE_H

#define PLAYER_APPEARANCE_VERSION 0xA7
#define PLAYER_HAIR_COLOR_COUNT 7
#define PLAYER_ACCENT_COLOR_COUNT 7

enum PlayerPaletteKind
{
    PLAYER_PALETTE_OVERWORLD,
    PLAYER_PALETTE_INTRO,
    PLAYER_PALETTE_FRONT,
    PLAYER_PALETTE_BACK,
    PLAYER_PALETTE_CREDITS,
};

void ResetPlayerAppearance(void);
bool8 HasPlayerAppearance(void);
void ApplyPlayerAppearancePalette(u16 offset, enum PlayerPaletteKind kind);

#endif
