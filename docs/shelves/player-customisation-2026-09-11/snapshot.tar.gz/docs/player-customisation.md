# Player customisation

New games replace Oak's boy/girl question with a live appearance selector:

- Style 1 and Style 2 use the existing Red and Leaf sprite sets.
- Hair: Original, Black, Brown, Blond, Auburn, Blue, Purple.
- Accent: Original, Red, Blue, Green, Purple, Orange, Teal.
- Up/down selects a row; left/right cycles choices. A cycles the selected choice or confirms Done. B returns to the style row.

The sprite style continues to use the existing `playerGender` field so avatar animations and existing story logic remain compatible. This screen does not add a separate gender-identity field.

Three bytes of the former `SaveBlock2.filler_90` reserve store a version marker and the two colour choices. The reserve remains eight bytes in total, so later fields and save size do not move. Actual offsets depend on this project's expanded Pokédex arrays. Legacy saves and invalid settings use original colours. Starting a new game initializes original colours before selection.

Palette hooks cover Oak's portrait (including after naming), player overworld animations and reflections, the naming icon, local battle back sprites, the local Trainer Card, player battle-transition portraits, and the credits. Original artwork and animation frames are retained. Hair and accent choices replace existing palette ramps; details sharing those palette entries also follow their colour. These are palette-based customisations, not independently masked recolours of every pixel.

The colour selections are local save data; they are not added to the link-trade or remote Trainer Card protocol.

## Validation

Run `python3 -B tools/test_player_appearance.py` for the compiled palette implementation's 245 colour/format combinations, original-colour fallback, invalid settings, palette bounds, and save-record copy round trips. Run `make -j4` for the ROM build.

After building, run `python3 -B tools/test_player_sprite_palettes.py` (requires Pillow) to check every used colour index in all 14 overworld sheets against the shared runtime palette and verify the compiled animation tiles match the source indices. These sheets must retain the canonical `player.pal` index order: PNG optimisers that reorder or compact palettes break the in-game colours even when the PNG itself looks unchanged.

The intro resource structure has compile-time checks for tilemap DMA alignment. The appearance cursor occupies a byte of the existing reserve, keeping both tilemap buffers at their original aligned offsets.

The isolated mGBA test ROM was advanced through the real intro. Live checks covered the default menu, Style 2 with blond hair and a blue accent, Style 1 with black hair and a blue accent, Done, entry into the naming screen, and return to Oak's name confirmation. Runtime assertions verified the saved style and colour bytes. Screenshots are `player-customisation-preview.png` and `player-customisation-style1.png`. The existing player's battery save was not used.

Regression verification used a fresh rebuilt ROM through the full intro into the player's bedroom. The restored background was checked on Oak's dialogue and the appearance menu. Style 2 retained blond hair and a blue accent in the overworld, with both back- and front-facing views checked after directional input. The gameplay screenshot is `player-customisation-overworld.png`. The palette/tile check covers all 14 movement sheets; cycling, surfing and fishing were not separately exercised in the emulator.
