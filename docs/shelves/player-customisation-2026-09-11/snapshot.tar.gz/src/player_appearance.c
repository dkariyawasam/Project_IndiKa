#include "global.h"
#include "gflib.h"
#include "player_appearance.h"

// Index zero retains the original palette, including all its shading.
static const u16 sHairColors[PLAYER_HAIR_COLOR_COUNT] = {
    0, RGB(9, 10, 12), RGB(20, 13, 8), RGB(30, 25, 13),
    RGB(26, 12, 7), RGB(12, 19, 29), RGB(23, 13, 28),
};
static const u16 sAccentColors[PLAYER_ACCENT_COLOR_COUNT] = {
    0, RGB(31, 12, 10), RGB(10, 20, 31), RGB(12, 27, 16),
    RGB(24, 13, 30), RGB(31, 20, 8), RGB(8, 27, 26),
};

void ResetPlayerAppearance(void)
{
    gSaveBlock2Ptr->appearanceVersion = PLAYER_APPEARANCE_VERSION;
    gSaveBlock2Ptr->hairColor = 0;
    gSaveBlock2Ptr->accentColor = 0;
}

bool8 HasPlayerAppearance(void)
{
    return gSaveBlock2Ptr->appearanceVersion == PLAYER_APPEARANCE_VERSION
        && gSaveBlock2Ptr->hairColor < PLAYER_HAIR_COLOR_COUNT
        && gSaveBlock2Ptr->accentColor < PLAYER_ACCENT_COLOR_COUNT;
}

static u16 Shade(u16 color, u8 strength)
{
    return RGB(((color & 31) * strength) / 100,
               (((color >> 5) & 31) * strength) / 100,
               (((color >> 10) & 31) * strength) / 100);
}

void ApplyPlayerAppearancePalette(u16 offset, enum PlayerPaletteKind kind)
{
    u16 colors[32];
    u16 hair, accent;
    u8 i, count = kind == PLAYER_PALETTE_INTRO ? 32 : 16;

    if (!HasPlayerAppearance())
        return;
    hair = sHairColors[gSaveBlock2Ptr->hairColor];
    accent = sAccentColors[gSaveBlock2Ptr->accentColor];
    if (hair == 0 && accent == 0)
        return;
    CpuCopy16(&gPlttBufferUnfaded[offset], colors, count * sizeof(u16));
    if (kind == PLAYER_PALETTE_INTRO)
    {
        if (hair)
            for (i = 0; i < 4; i++)
                colors[6 + i] = Shade(hair, 100 - i * 20);
        if (accent)
            for (i = 0; i < 5; i++)
                colors[27 + i] = Shade(accent, 100 - i * 15);
    }
    else if (kind == PLAYER_PALETTE_FRONT)
    {
        if (hair)
            colors[4] = Shade(hair, 65);
        if (accent)
        {
            colors[12] = accent;
            colors[13] = Shade(accent, 65);
        }
    }
    else
    {
        if (hair)
        {
            colors[1] = hair;
            colors[4] = Shade(hair, 65);
            if (kind != PLAYER_PALETTE_CREDITS)
                colors[8] = Shade(hair, 40);
        }
        if (accent)
        {
            colors[11] = accent;
            colors[12] = Shade(accent, 65);
        }
    }
    LoadPalette(colors, offset, count * sizeof(u16));
}
